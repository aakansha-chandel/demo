import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { AreaChartComponent } from '../area-chart/area-chart.component';

@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.css']
})
export class DatepickerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
