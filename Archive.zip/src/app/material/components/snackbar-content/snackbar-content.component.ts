import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snackbar-content',
  templateUrl: './snackbar-content.component.html',
  styleUrls: ['./snackbar-content.component.css']
})
export class SnackbarContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
